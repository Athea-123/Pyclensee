def main():
    print("This is the Pyclense CLI!")
